---
tipo: mecanica
estado: borrador
---
# Deslizamiento

## Lo definido #decidido
- El pingüino se desliza por la pendiente que está abajo de la meseta de spawn, hasta abajo del acantilado.
- Se desliza de panza → [[D-004 Pose y animaciones del pingüino]]
- **A / D**: movimiento lateral para esquivar obstáculos.
- **Espacio**: salto de panza (troncos, témpanos del río) → [[D-009 Mapa base y controles]] · [[D-007 Jugabilidad base del recorrido]]
- Implementación en PINGUINO TEST (velocidad tope 120, cámara detrás) → [[Prototipo jugable v1]]

## Efectos → [[D-018 Efectos de movimiento]]
- Velocidad: líneas, estela, rachas de viento, destellos y FOV que crecen con la velocidad.
- Frenado: plumas de nieve a los lados y raspado al perder velocidad.
- Giros: spray hacia afuera de la curva, marca en la nieve e inclinación de cámara.
- Velocidad máxima: temblor de cámara y vibración del control.
- Rampas de impulso → [[D-017 Rampas de impulso]]

## Por definir #pendiente
- Física: velocidad, fricción
- ¿Botón para frenar? (hoy no hay; el efecto de frenado sale al perder velocidad sola)
- Velocidad mínima para cruzar el río (ver [[Mapa]])
- Cámara

Anterior: [[Vuelo]] · Ver: [[Obstáculos]] · [[Mapa]]
