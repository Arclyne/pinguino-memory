---
tipo: plan
---
# Preguntas abiertas

Al resolver una pregunta, se crea su decisión en `03 Decisiones` y se tacha aquí.

## Juego
- [ ] ¿Cuál es el objetivo? (distancia, puntaje, llegar abajo, carreras)
- [x] ~~¿Qué pasa al chocar con una estructura?~~ → ragdoll y muerte, [[D-008 Choque mortal, sin puntos de control y GUI minimalista]]
- [x] ~~¿Qué pasa al llegar abajo?~~ → se muestra el tiempo y empieza el siguiente nivel ya montado en la resortera ([[D-016 Avance automático al siguiente nivel]])
- [ ] ¿Single player o multijugador?
- [ ] ¿Hay progresión? (mejoras de resortera, skins de pingüino, nuevos acantilados) — hay skins y peces propuestos en [[Lobby y skins]]
- [ ] PINGUINO TEST ya tiene los 4 niveles, el lobby y la economía. ¿Se puede dejar de usar "Lugar de Alucinarse: 11112026_1"?

## Personaje
- [ ] ¿Se aprueba la hoja de personaje de bloques del pingüino? ¿Cómo será la textura de studs? (se define en Blender) → [[Personaje - Pingüino]]

## Controles
- [x] ~~¿Cómo se apunta y se elige la fuerza?~~ → [[D-005 Controles de la resortera]] (en PC; falta celular/consola y el rango exacto de ángulos)
- [x] ~~¿Control al deslizarse?~~ → A/D y Espacio, de panza: [[D-009 Mapa base y controles]] · [[D-007 Jugabilidad base del recorrido]]
- [ ] ¿Control en el aire?

## Obstáculos
- [x] ~~¿Qué tipos de estructuras hay?~~ → [[D-003 Tipos de obstáculos]]

## Alcance
- [ ] ¿Qué entra en el MVP?
- [ ] ¿Monetización? (gamepasses, productos) — precios en Robux aún sin decidir
- [x] ~~¿El lobby es aparte o la meseta del nivel 1?~~ → meseta ([[D-014 Lobby en la meseta y peces como moneda]])
- [x] ~~¿Cómo se ganan los peces?~~ → dispersos en cada nivel, estilo Subway Surfers ([[D-014 Lobby en la meseta y peces como moneda]])

## Mapa
- [ ] ¿Qué pasa si el pingüino cae fuera de la pista al lanzarlo?
- [x] ¿Qué pasa al caer al río?
- [x] ¿Cuánto debe durar una bajada?
- [x] ¿El cañón va a media bajada o al final?
- [ ] ¿Los saltos del nivel 3 (huecos de 20–22 studs) se sienten justos con la física real? Hay que probarlo jugando.
- [x] ~~¿Qué hace el portal del nivel 3?~~ → lleva al nivel 4 ([[D-012 Nivel 4 en Studio]])
- [ ] ¿Qué hace el portal del nivel 4? ¿Lleva a un nivel 5 o regresa al inicio? (hoy, al terminar el nivel 4 se repite el nivel 4)
- [ ] ¿Se agregan rampas de impulso al nivel 4? (no tiene rampas)
- [ ] ¿Los ciervos deben moverse (animación de cabeza y cola) en el juego?
- [ ] ¿Los niveles se desbloquean en orden o se pueden elegir?
