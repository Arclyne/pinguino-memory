---
tipo: indice
actualizado: 2026-11-13
---
# 🐧 Pingüino Resortera — Índice

> Punto de entrada del vault. Claude lo lee primero en cada sesión.

## Estado actual
- **Fase:** Prototipo jugable en **PINGUINO TEST** (placeId 76340917059535): 4 niveles encadenados (al terminar uno empieza el siguiente ya montado en la resortera), lobby, peces, skins, ruleta, tabla y datos con DataKit → [[Prototipo jugable v1]] · [[Mapa]]
- Rampas de impulso en los niveles 1, 2 y 3, y efectos de velocidad, frenado, giro y temblor → [[D-017 Rampas de impulso]] · [[D-018 Efectos de movimiento]]
- El place viejo "Lugar de Alucinarse: 11112026_1" quedó atrás: PINGUINO TEST ya tiene todo → [[Preguntas abiertas]]
- ⚠️ **NADA de lo diseñado el 2026-11-12 (después del nivel 1) está en Studio todavía.** Cuando Angel diga **"agrega lo que no agregamos"** (o "agrega todo lo que no se agregó"), meter a Studio TODO lo de [[Pendiente de agregar a Studio]]
- **Pendiente aprobado:** cuando Angel diga "agrega la decoración al nivel 2", meter a Studio [[Nivel 2 - Decoración Festival de Faroles]]
- **Siguiente paso:** que Angel juegue los 4 niveles seguidos y ajuste la sensación (impulso, temblor, frenado en `GameConfig.Boost` / `GameConfig.Feel`); decidir qué pasa al terminar el nivel 4; controles de celular/consola y [[Preguntas abiertas]]
- **Última sesión:** [[2026-11-13]]

## Mapa
| Sección | Notas |
|---|---|
| Contexto | [[Contexto para Claude]] |
| 01 Visión | [[Concepto]] · [[Core Loop]] |
| 02 Diseño | [[Personaje - Pingüino]] · [[Mapa]] · [[Lobby y skins]] · [[Nivel 2 - Aldea Nevada]] · [[Nivel 2 - Decoración Festival de Faroles]] · [[Nivel 3 - Ciudad Nevada]] · [[Nivel 4 - Valle del Avión]] · [[Resortera]] · [[Vuelo]] · [[Deslizamiento]] · [[Obstáculos]] |
| 03 Decisiones | [[Registro de decisiones]] |
| 04 Planeación | [[Roadmap]] · [[Backlog]] · [[Preguntas abiertas]] |
| 05 Técnico | [[Arquitectura]] · [[Convenciones]] · [[Prototipo jugable v1]] |
| 06 Bitácora | Una nota por sesión (`AAAA-MM-DD`) |
| 07 Referencias | [[Referencias]] |

## Etiquetas
`#pendiente` `#decidido` `#idea` `#bug`
