---
tipo: decision
id: D-018
fecha: 2026-11-13
estado: aceptada
---
# D-018 Efectos de movimiento #decidido

## Decisión (pedido de Angel)
- Efectos especiales por velocidad.
- Efectos al ir frenando.
- Efectos al moverse a izquierda y derecha.
- Temblor de pantalla cuando vas muy rápido (velocidad máxima).

## Cómo quedó (detalles que eligió Claude) #idea
| Efecto | Qué se ve | Cuándo |
|---|---|---|
| Velocidad | Líneas de velocidad, spray, estela que se pone cian brillante, rachas de viento, destellos de hielo, FOV más abierto | Crece con la velocidad; rachas desde velocidad media, destellos cerca del tope |
| Frenado | Plumas de nieve a los dos lados, sonido de raspado, FOV se cierra un poco | Al perder velocidad en el suelo (más de 8 studs/s², máximo a 45) |
| Izquierda / derecha | Spray hacia afuera de la curva, marca en la nieve, cámara se inclina hasta 6° | Al girar en el suelo; en el aire solo una inclinación leve |
| Velocidad máxima | Temblor de cámara y vibración del control | Desde 132 studs/s, máximo a 150 (impulsos y bajadas fuertes) |

- Todo se ajusta en `GameConfig.Feel`.
- No hay botón de frenar: el efecto sale cuando el pingüino pierde velocidad solo (al aterrizar, en tramos planos, en curvas o al terminar un impulso).

## Implementación
- `Client.Race.CameraFeel` (temblor, inclinación y FOV que usa `ChaseCamera`).
- `Client.Race.Feel`: `RaceFeel` (coordina), `BrakeEffects`, `CarveEffects`, `TopSpeedRumble`, `BoostEffects`, `ParticleFactory`, `MotionSample`.
- `Client.Race.SpeedEffects` ampliado (niveles por velocidad y modo impulso).

## Relacionado
- [[Deslizamiento]] · [[D-017 Rampas de impulso]]
