---
tipo: decision
id: D-017
fecha: 2026-11-13
estado: aceptada
---
# D-017 Rampas de impulso #decidido

## Decisión (pedido de Angel)
- Las rampas dan un impulso de velocidad con efectos. Se usan las rampas que ya había en los mapas.

## Rampas convertidas
| Nivel | Pieza | Nota |
|---|---|---|
| 1 | `Obstacles.SnowMound` | Montículo antes del río; con el impulso se vuela el río |
| 2 | `Obstacles.Bridge` (las 3 tablas que suben) | La bajada del puente no impulsa |
| 3 | `Obstacles.ramp_39.Ramp` | Rampa del techo del helipuerto |
| 4 | — | No tiene rampas |

## Cómo quedó (detalles que eligió Claude) #idea
- Etiqueta `BoostRamp` en las piezas. Flechas de neón cian que pulsan (etiqueta `PulseGlow`), sin colisión.
- Impulso: sube la velocidad a **170** (tope temporal **185**) durante **1.8 s**, con 25 % de fricción; luego el tope regresa a 145 en 0.8 s (`GameConfig.Boost`).
- Efectos: estallido de destellos y nieve, estela cian, luz cian, golpe de cámara y FOV, sonido de lanzamiento más agudo, líneas de velocidad cian.
- Script para reconstruir: `05 Técnico/InstallBoostRamps_v01.lua` (calcula solo hacia dónde sube cada pieza).
- Probado en Play: el montículo del nivel 1 sube la velocidad de 93 a 165–190.

## Relacionado
- [[Obstáculos]] · [[D-003 Tipos de obstáculos]] · [[D-018 Efectos de movimiento]]
