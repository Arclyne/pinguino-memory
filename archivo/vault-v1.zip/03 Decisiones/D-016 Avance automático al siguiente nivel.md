---
tipo: decision
id: D-016
fecha: 2026-11-13
estado: aceptada
---
# D-016 Avance automático al siguiente nivel #decidido

## Decisión (pedido de Angel)
- Al terminar un mapa, empieza solo el siguiente y el jugador queda **arriba de la resortera**, listo para lanzarse otra vez.

## Cómo quedó (detalles que eligió Claude) #idea
- Espera **2.5 s** después de cruzar la meta, para ver el tiempo (`GameConfig.Race.AutoAdvanceSeconds`).
- El siguiente nivel es el destino del portal de ese nivel (`DestinationLevel`): 1 → 2 → 3 → 4. El portal del nivel 4 no tiene destino, así que **el nivel 4 se repite**. Sigue abierto qué hace el nivel 4 → [[Preguntas abiertas]]
- Si el jugador entra al portal antes de los 2.5 s, avanza en ese momento.
- Si la resortera del siguiente nivel está ocupada por otro jugador, llega a la meseta de ese nivel en `Idle` y se sube con E.

## Implementación
- `Server.Services.LevelFlowService` (nuevo), `SlingshotService.mountAtLevel`, `LevelRegistry.nextLevel`, transición `Finished → Aiming` en `RunStateService`.
- Probado en Play: meta del nivel 1 → a los 2.5 s en `Aiming` sobre la resortera del nivel 2.

## Relacionado
- [[Arquitectura]] · [[D-010 Nivel 2 y portal entre niveles]]
